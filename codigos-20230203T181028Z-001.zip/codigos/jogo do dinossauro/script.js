let jogador = document.querySelector('#jogador')
let obstaculo = document.querySelector('#obstaculo')
function pular(){
    if(jogador.classList != 'animar'){
        jogador.classList.add('animar')
    }
    setTimeout(function(){
        jogador.classList.remove('animar')
    },500)
}
var colisao=setInterval(function(){
    var topopersonagem=parseInt(
        window.getComputedStyle(jogador).getPropertyValue('top')
    )
    var esquerdapersonagem=parseInt(
        window.getComputedStyle(obstaculo).getPropertyValue('left')
    )
    if(esquerdapersonagem< 20 && esquerdapersonagem > 0 && topopersonagem >= 130){
        obstaculo.style.animation='none'

        obstaculo.style.display='none'
        alert('tente novamente')


        
    }
},10)